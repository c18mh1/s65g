//
//  Engine2.swift
//  Assignment2
//
//  Created by Michelle on 7/21/16.
//  Copyright © 2016 Michelle. All rights reserved.
//

import UIKit

class Engine2: UIViewController {

    class func neighbors(row: Int, col column: Int) -> [(Int, Int)]
    {
        var neighbors: [(Int, Int)] = []
        let rowPlusNine = (row+9)
        let colPlusNine = (column+9)
        let rowPlusOne = (row+1)
        let colPlusOne = (column+1)
        
        let a: (Int, Int) = (rowPlusNine%10, colPlusNine%10)
        neighbors.append(a)
        
        let b: (Int, Int) = ((row%10), colPlusNine%10)
        neighbors.append(b)
        
        let c: (Int, Int) = (rowPlusOne%10, colPlusNine%10)
        neighbors.append(c)
        
        let d: (Int, Int) = (rowPlusNine%10, (column%10))
        neighbors.append(d)
        
        let e: (Int, Int) = (rowPlusOne%10, (column%10))
        neighbors.append(e)
        
        let f: (Int, Int) = (rowPlusNine%10, colPlusOne%10)
        neighbors.append(f)
        
        let g: (Int, Int) = ((row%10), (colPlusOne%10))
        neighbors.append(g)
        
        let h: (Int, Int) = (rowPlusOne%10, colPlusOne%10)
        neighbors.append(h)
        
        return neighbors
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
