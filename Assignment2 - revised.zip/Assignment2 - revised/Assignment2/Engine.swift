//
//  Engine.swift
//  Assignment2
//
//  Created by Michelle on 7/21/16.
//  Copyright © 2016 Michelle. All rights reserved.
//

import UIKit

class Engine: UIViewController {

    class func step (before: [[Bool]]) -> [[Bool]]
    {
        var after: [[Bool]] = []
        
        func returnNeighbors(x: Int, y: Int) -> Int
        {
            var aliveNeighbors: Int = 0;
            
            var aliveCount: Int = 0;
            
            for i in 0..<before.count
            {
                for j in 0..<before[i].count
                {
                    if(before[i][j])
                    {
                        aliveCount = aliveCount + 1
                    }
                }
            }
            
            switch before[x][y]
            {
                
            case before[(x+9)%10][(y+9)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[(x+9)%10][y%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[(x+9)%10][(y+1)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[x%10][(y+9)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[x%10][(y+1)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[(x+1)%10][(y+9)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[(x+1)%10][y%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[(x+1)%10][(y+1)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            default:
                aliveNeighbors = aliveNeighbors + 0
            }
            
            return aliveNeighbors
        }//neighbors
        
        for x in 0..<before.count
        {
            for y in 0..<before[x].count
            {
                let numberOfAliveNeighbors: Int = returnNeighbors(x, y: y)
                
                //if cell alive
                if (before[x][y])
                {
                    //http://stackoverflow.com/questions/33975542/swift-2-expression-pattern-of-type-bool-cannot-match-values-of-type-int
                    
                    switch numberOfAliveNeighbors
                    {
                    case let numberOfAliveNeighbors where numberOfAliveNeighbors < 2:
                        after[x][y] = false
                        
                    case let numberOfAliveNeighbors where numberOfAliveNeighbors == 2:
                        after[x][y] = true
                        
                    case let numberOfAliveNeighbors where numberOfAliveNeighbors == 3:
                        after[x][y] = true
                        
                    case let numberOfAliveNeighbors where numberOfAliveNeighbors > 3:
                        after[x][y] = false
                        
                    default:
                    after[x][y] = before[x][y]
                        
                    }
                }
                    
                else if (!before[x][y])
                {
                    switch numberOfAliveNeighbors
                    {
                    case let numberOfAliveNeighbors where numberOfAliveNeighbors == 3:
                        after[x][y] = true
                        
                    default:
                        after[x][y] = before[x][y]
                        
                    }
                }

            }
        }
        
        //count living cells in after
        var livingInAfter: Int = 0;
        for x in 0..<after.count
        {
            for y in 0..<after[x].count
            {
                if(after[x][y])
                {
                    livingInAfter = livingInAfter + 1
                }
            }
        }
    
        return after
        
    }//step
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
