//
//  Problem2ViewController.swift
//  Assignment2
//
//  Created by Michelle on 7/17/16.
//  Copyright © 2016 Michelle. All rights reserved.
//

import UIKit

class Problem2ViewController: UIViewController {

    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var myButton: UIButton!
    
    
    @IBAction func buttonPressed(sender: AnyObject)
    {
        print("We were clicked")
        textView.text = "Button was clicked."
        
        //2d array of Bools
        var before: [[Bool]] = Array(count: 10, repeatedValue: Array(count: 10, repeatedValue: false))
        var after = Array(count: 10, repeatedValue: Array(count: 10, repeatedValue: false))
        
        //sets 1/3 of array alive
        for x in 0..<before.count
        {
            for y in 0..<before.count
            {
                if arc4random_uniform(3) == 1
                {
                    before[x][y] = true
                }
            }
        }
        
        //count number of living cells in before array
        var aliveCount: Int = 0;
        for i in 0..<before.count
        {
            for j  in 0..<before.count
            {
                if(before[i][j] == true)
                {
                    aliveCount = aliveCount + 1
                    textView.text = "There are \(aliveCount) live cells in 'before'"
                }
            }
        }
        
        //loop through the before array and count the living neigbors of each cell using a switch statement, observing the wrapping rules
        func returnNeighbors(x: Int, y: Int) -> Int
        {
            var aliveNeighbors: Int = 0
            
            switch before[x][y]
            {
                
            case before[(x+9)%10][(y+9)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[(x+9)%10][y%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[(x+9)%10][(y+1)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[x%10][(y+9)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[x%10][(y+1)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[(x+1)%10][(y+9)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[(x+1)%10][y%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            case before[(x+1)%10][(y+1)%10] == true:
                aliveNeighbors = aliveNeighbors + 1
                
            default:
                aliveNeighbors = aliveNeighbors + 0
            }
            
            return aliveNeighbors
        }
        
        //place the result of applying the rules above into the corresponding cell in the fter array 
        for x in 0..<before.count
        {
            for y in 0..<before.count
            {
                let numberOfAliveNeighbors: Int = returnNeighbors(x, y: y)
                
                if (before[x][y])
                {
                    
                    //http://stackoverflow.com/questions/33975542/swift-2-expression-pattern-of-type-bool-cannot-match-values-of-type-int
                    
                    switch numberOfAliveNeighbors
                    {
                    case let numberOfAliveNeighbors where numberOfAliveNeighbors < 2:
                        after[x][y] = false
                        
                    case let numberOfAliveNeighbors where numberOfAliveNeighbors == 2:
                        after[x][y] = true
                        
                    case let numberOfAliveNeighbors where numberOfAliveNeighbors == 3:
                        after[x][y] = true
                        
                    case let numberOfAliveNeighbors where numberOfAliveNeighbors > 3:
                        after[x][y] = false
                        
                    default:
                        before[x][y] = after[x][y]
                    }
                }
                
                else if (!before[x][y])
                {
                    switch numberOfAliveNeighbors
                    {
                    case let numberOfAliveNeighbors where numberOfAliveNeighbors == 3:
                        after[x][y] = true
                        
                    default:
                        before[x][y] = after[x][y]
                    }
                }
            }
        }
        
        
        //count and print the number of living ceclls in after to the UITextView
        var livingAfter: Int = 0
        
        for x in 0..<after.count
        {
            for y in 0..<after.count
            {
                if(after[x][y])
                {
                    livingAfter = livingAfter + 1
                    textView.text = "There are \(livingAfter) live cells in 'after'."
                }
            }
        }
        
    }//buttonPressed
    
    
    //PROBLEM 3:
    /*
    var beforeArray: [[Bool]] = Array(count: 10, repeatedValue: Array(count: 10, repeatedValue: false))
    var afterArray: [[Bool]]
    {
        return Engine.step(beforeArray);
    }
    */
    
    
    //PROBLEM 4:
    /*
    func step2(before: [[Bool]]) -> [[Bool]]
    {
        var after: [[Bool]] = []
        
        for x in 0..<before.count
        {
            for y in 0..<before[x].count
            {
                Engine2.neighbors(x, col: y)
                var neighborArray: [(Int, Int)] = Engine2.neighbors(x, col: y)
                
                for i in 0..<neighborArray.count
                {
                    let xcor = neighborArray[i].0
                    let ycor = neighborArray[i].1
                    
                    var live = 0
                    
                    if (before[xcor][ycor])
                    {
                        live = live + 1
                    }
                    
                    //if cell is alive
                    if(before[x][y])
                    {
                        switch live
                        {
                        case let live where live<2: after[x][y] = false
                        case let live where live==2: after[x][y] = true
                        case let live where live==3: after[x][y] = true
                        case let live where live>3: after[x][y] = false
                        default: after[x][y] = before[x][y]
                        }
                    }
                    
                    //if cell is dead
                    else if(!before[x][y])
                    {
                        switch live
                        {
                        case let live where live==3: after[x][y] = true
                        default: after[x][y] = before[x][y]
                        }
                    }
                }
            }
        }
        
        return after
        
    }//step2
    */
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Problem 2"
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


    /*
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

} //class
